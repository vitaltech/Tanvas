<?php
// TODO: Allow discounts to be specified based on how many liters of solution
	
/**
 * Registers home page template widget areas
 */
function tanvas_widgets_init() {
	// register_sidebar( array(
	// 	'name' 	=> 'Home Doorway Buttons'))
}
?>